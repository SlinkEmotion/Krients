﻿/// api_version=2
var script = registerScript({
	name: "JianCe",
	version: "1.0",
	authors: ["JianCe"]
}); 
function qz(int){
	return( int - int%1 );
}
function qz2(int){
	return(Math.round(int*10)) ;
}
var Fonts = Java.type("net.ccbluex.liquidbounce.ui.font.Fonts");
var Color = Java.type("java.awt.Color");
var ScaledResolution = Java.type("net.minecraft.client.gui.ScaledResolution");
var White = new Color(255, 0, 0).getRGB();

script.registerModule({
	name: "sheild",
	description: "检测血量",
    category: "Combat",
}, function (module) {
    var lastX,lastZ,mcWidth,mcHeight,HPCStr="0 点血";
	var HP=20,HPC;
	module.on("enable", function()
    {
        Chat.print("\n已开启sheild.js");
        Chat.print("\n");
    });
    module.on("update", function () {
		var SR = new ScaledResolution(mc)
		mcWidth=SR.getScaledWidth();
		mcHeight=SR.getScaledHeight();
        lastX=mc.thePlayer.posX;
        lastZ=mc.thePlayer.posZ;
        HPC=qz2(HP-mc.thePlayer.getHealth())/10;
        
        if(HPC>0) HPCStr="[Level检测]你失去了"+HPC+"点血";
        if(HPC<0) HPCStr="[Level检测]你回复了"+-HPC+"点血";
        if(HPC!=0) Chat.print(HPCStr);
        HP=mc.thePlayer.getHealth();
    })
   // module.on("attack", function(eventData) {
   //     Chat.print("attack\n");
   // });
    module.on("render2D", function() {
		Fonts.minecraftFont.drawString(qz(mc.thePlayer.getHealth()),(mcWidth/2),(mcHeight/2)-30,White);
	})
})