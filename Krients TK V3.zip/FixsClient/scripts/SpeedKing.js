var scriptName = "TKHelper"
var scriptVersion = 1.0;
var scriptAuthor = "Sock"
var TKHelperModule = new TKHelperModule();
var TKHelperClient;
var hurt = false;
var tick = 0;
var toggle = false;
var Fly = moduleManager.getModule("Speed")
var Fly = moduleManager.getModule("Fly")
var TargetStrafe = moduleManager.getModule("TargetStrafe")
var onn = false;
var delaytick = 0;
var shouldrun = false;
var master = true;
var health = 0;
var target;
var dehealth = 0;

function TKHelperModule() {
		var tickget = value.createInteger("Tick",40,0,60)
		var flyvalue = value.createBoolean("Fly",true)
		var suoxuevalue = value.createBoolean("SuoXue",true)
		var targetstrafevalue = value.createBoolean("TargetStrafe",true)
		var autojumpvalue = value.createBoolean("AutoJump",true)
		var debugtickget = value.createInteger("DebugTick",5,0,20)
		var attack = value.createBoolean("AttackFly[HugeAmountBug]",false)
		this.getName = function(){
			return "FlyKing"
		}
		
		this.getTag = function() {
			return "Hyt"
		}

		this.getDescription = function() {
			return "by soooock q 1647054792"
		}
		this.onDisable = function(){
			if(flyvalue.get()){
				Fly.setState(false);
			}
			if(targetstrafevalue.get()){
				TargetStrafe.setState(false);
			}
			if(suoxuevalue.get()){
				fastuse.setState(false);
				gapple.setState(false);
			}
		}
									
		this.getCategory = function() {
			return "Combat"
		}
		this.addValues = function(values) {
			values.add(tickget);
			values.add(flyvalue);
			values.add(suoxuevalue);
			values.add(targetstrafevalue);
			values.add(autojumpvalue);
			values.add(debugtickget);
			values.add(attack);
		}	
		this.onEnable = function() {
			toggle = false;
		}
		
		this.onAttack = function(){
			if(mc.thePlayer.isBurning()){
				return;
			}
			target = event.getTargetEntity();
			if(!(target.getHealth() == dehealth)){
				if(mc.thePlayer.onGround){
					if(autojumpvalue.get()){
						mc.thePlayer.jump();
					}
				}
				shouldrun = true;
			}
			dehealth = target.getHealth()
		}

		this.onPacket = function(){
			if(mc.thePlayer.isBurning()){
				return;
			}
			if(toggle==false){
				if(mc.thePlayer.hurtTime > 0){
					if(mc.thePlayer.getHealth() == health){//钓竿
						if(targetstrafevalue.get()){
							TargetStrafe.setState(false);
						}
						if(flyvalue.get()){
							Fly.setState(false);
						}
						if(suoxuevalue.get()){
							fastuse.setState(false);
							gapple.setState(false);
						}
						return;
					}
					if(mc.thePlayer.onGround){
						if(autojumpvalue.get()){
							mc.thePlayer.jump();
						}
					}
					shouldrun = true;

				}else{
					hurt=false;
				}
				health = mc.thePlayer.getHealth();
			}
			if(mc.thePlayer.hurtTime > 0){
				hurt=true;
			}else{
				hurt=false;
			}

		}
		this.onUpdate = function() {
			if(mc.thePlayer.isBurning()){
				if(targetstrafevalue.get()){
					TargetStrafe.setState(false);
				}
				if(flyvalue.get()){
					Fly.setState(false);
				}
				if(suoxuevalue.get()){
					fastuse.setState(false);
					gapple.setState(false);
				}
				return;
			}
			if(shouldrun){
				delaytick = delaytick + 1;
				if(debugtickget.get()==delaytick){
					shouldrun = false;
					delaytick = 0;
					hurt=true;
					toggle = true;
					if(targetstrafevalue.get()){
						TargetStrafe.setState(true);
					}
					if(flyvalue.get()){
						Fly.setState(true);
					}
					if(suoxuevalue.get()){
						fastuse.setState(true);
						gapple.setState(true);
					}
				}
			}
			if(toggle == true){
				if(hurt==false){
					tick=tick+1;
				}else{
					tick=0;
				}
			}
			if(tick==tickget.get()){
				tick=0
				toggle=false;
				if(flyvalue.get()){
					Fly.setState(false);
				}
				if(targetstrafevalue.get()){
					TargetStrafe.setState(false);
				}
				if(suoxuevalue.get()){
					fastuse.setState(false);
					gapple.setState(false);
				}
			}

		}
}

function onEnable() {
	TKHelperClient = moduleManager.registerModule(TKHelperModule);
}
function onDisable() {
	moduleManager.unregisterModule(TKHelperModuleClient);

}
